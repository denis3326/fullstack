<!DOCTYPE html>
<html>
    <head>
        <style>
            body {
                font-family: "Open Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", Helvetica, Arial, sans-serif; 
            }
        </style>
        <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script>
            Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'check again your inputs!',
            });
        </script>
    </head>
    <body></body>
</html>