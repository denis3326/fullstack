<?php require './code/buyC.php'?>

<div class="card text-center">
  <div class="card-body">
    <h5 class="card-title"><?php echo $row['itm_title']; ?></h5>
    <p class="card-text"><?php echo $row['itm_text']; ?></p>
    <h5 class="card-title"><?php echo $row['price']; ?>$</h5>
    <br><br>
    <form method="POST">
        count: <input type="number" name="count"><br><br>
        <button type="submit" name="buy" class="btn btn-danger">BUY</button>
    </form>
  </div>
</div>
<br>


